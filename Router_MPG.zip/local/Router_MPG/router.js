var hm = require('header-metadata');
var service = require('service-metadata');

//Read input
session.input.readAsBuffers(function (error, input) {
  if (error) {
    // handle error
    session.output.write (error.errorMessage);
  }
  else {
	if (input.indexOf('name') > -1) {
		//service.routingUrl = 'http://localhost:2000/profile';
		hm.current.set("Content-type", "text/xml");
		service.setVar('var://service/routing-url', 'http://localhost:2000/profile');
		console.error('****Logging: ' + input);
	}
	if (input == '') {
		session.output.write("Please enter something");
	}
  }
});